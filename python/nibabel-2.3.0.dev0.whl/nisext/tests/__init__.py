# Tests for nisext package
