# init for externals package
from collections import OrderedDict

from ..deprecated import ModuleProxy as _ModuleProxy
six = _ModuleProxy('nibabel.externals.six')
